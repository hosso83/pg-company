import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { ProjectCard } from "@/components/project-card"
import { getProjects } from "@/lib/strapi"
import { Button } from "@/components/ui/button"
import type { Metadata } from "next/metadata"

export const metadata: Metadata = {
  title: "Our Projects | Engineering Global",
  description:
    "Discover our global portfolio of infrastructure projects. From transport systems to renewable energy, we deliver projects that transform communities worldwide.",
  keywords: [
    "infrastructure projects",
    "engineering portfolio",
    "transport projects",
    "energy projects",
    "global infrastructure",
    "project delivery",
  ],
  openGraph: {
    title: "Our Projects | Engineering Global",
    description: "World-class infrastructure projects delivering technical excellence and innovation globally.",
    type: "website",
  },
}

export default async function ProjectsPage() {
  let projects = []
  let pagination = null

  try {
    const projectsData = await getProjects(1, 12)
    projects = projectsData.data
    pagination = projectsData.meta.pagination
  } catch (error) {
    console.error("[v0] Error fetching projects from Strapi:", error)
  }

  const fallbackProjects = [
    {
      title: "Los Angeles Regional Connector",
      description:
        "We helped to deliver the Los Angeles Regional Connector, encouraging Angelenos towards public transport with modern, efficient rail infrastructure.",
      location: "Los Angeles, USA",
      region: "North America",
      slug: "la-regional-connector",
    },
    {
      title: "Kitakyushu Hibikinada Offshore Wind",
      description:
        "The largest privately financed offshore wind energy project in Japan provides a model for others to follow as the country strives towards net zero.",
      location: "Kitakyushu, Japan",
      region: "Asia",
      slug: "kitakyushu-offshore-wind",
    },
    {
      title: "Ontario Line, Toronto",
      description:
        "Toronto's largest and most complex transport project to date, the Ontario Line is being delivered to transform urban mobility.",
      location: "Toronto, Canada",
      region: "North America",
      slug: "ontario-line-toronto",
    },
    {
      title: "Liverpool Baltic Station",
      description:
        "Transforming Liverpool's Baltic Triangle district with a new station to maximize connectivity and regenerate the area.",
      location: "Liverpool, UK",
      region: "UK",
      slug: "liverpool-baltic-station",
    },
    {
      title: "Philadelphia Stormwater Management",
      description:
        "A comprehensive project to double sewer capacity and reduce stormwater flooding during large storm events.",
      location: "Philadelphia, USA",
      region: "North America",
      slug: "philadelphia-stormwater",
    },
    {
      title: "UK Net Zero Grid Development",
      description:
        "Supporting the UK government's ambitious programme of wind farm construction and new transmission infrastructure for a greener, more resilient energy system.",
      location: "United Kingdom",
      region: "UK",
      slug: "uk-net-zero-grid",
    },
    {
      title: "Nepal Climate Resilience Programme",
      description:
        "A UK aid funded programme helping communities adapt to climate change with technical support and financial aid for resilience projects.",
      location: "Nepal",
      region: "Asia",
      slug: "nepal-climate-programme",
    },
    {
      title: "HS2 Digital Innovation",
      description:
        "Enhancing the observational method on HS2 with DAARWIN, new software that employs machine learning for dramatic time and safety benefits.",
      location: "United Kingdom",
      region: "UK",
      slug: "hs2-digital-innovation",
    },
    {
      title: "Floating Wetlands Water Treatment",
      description:
        "Engineering natural processes with 31 new floating wetlands providing biological water treatment to bring an abandoned resource back into use.",
      location: "United Kingdom",
      region: "UK",
      slug: "floating-wetlands-treatment",
    },
  ]

  const displayProjects =
    projects.length > 0
      ? projects
      : fallbackProjects.map((p, i) => ({ id: i, attributes: { ...p, image: { data: null } } }))

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-primary py-20 text-primary-foreground">
          <div className="container">
            <div className="mx-auto max-w-4xl text-center">
              <h1 className="mb-6 text-balance text-5xl font-bold md:text-6xl">Our Projects</h1>
              <p className="text-pretty text-xl opacity-90">
                Applying technical excellence and innovation to deliver projects that transform our clients' businesses,
                our communities and employee opportunities around the world.
              </p>
            </div>
          </div>
        </section>

        {/* Filter Bar */}
        <section className="border-b border-border bg-background">
          <div className="container py-6">
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-sm font-medium text-muted-foreground">Filter by region:</span>
              <Button variant="outline" size="sm" className="bg-transparent">
                All Regions
              </Button>
              <Button variant="ghost" size="sm">
                North America
              </Button>
              <Button variant="ghost" size="sm">
                UK
              </Button>
              <Button variant="ghost" size="sm">
                Asia
              </Button>
              <Button variant="ghost" size="sm">
                Europe
              </Button>
              <Button variant="ghost" size="sm">
                Middle East
              </Button>
            </div>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="py-20">
          <div className="container">
            <div className="mb-8 flex items-center justify-between">
              <p className="text-muted-foreground">
                Showing {displayProjects.length} {displayProjects.length === 1 ? "project" : "projects"}
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {displayProjects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>

            {pagination && pagination.pageCount > 1 && (
              <div className="mt-12 flex justify-center gap-2">
                <Button variant="outline" disabled className="bg-transparent">
                  Previous
                </Button>
                <Button variant="outline" className="bg-primary text-primary-foreground">
                  1
                </Button>
                <Button variant="outline" className="bg-transparent">
                  2
                </Button>
                <Button variant="outline" className="bg-transparent">
                  3
                </Button>
                <Button variant="outline" className="bg-transparent">
                  Next
                </Button>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
