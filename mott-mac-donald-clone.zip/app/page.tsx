import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { HeroSection } from "@/components/hero-section"
import { ProjectCard } from "@/components/project-card"
import { ServiceCard } from "@/components/service-card"
import { StatsSection } from "@/components/stats-section"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { getProjects, getServices, getPageContent } from "@/lib/strapi"
import type { Metadata } from "next/metadata"

export const metadata: Metadata = {
  title: "Engineering Global | Delivering Excellence in Infrastructure",
  description:
    "Global engineering, management and development consultancy. We plan, design, deliver and maintain infrastructure that is integral to daily life across transport, energy, water, and buildings.",
  keywords: [
    "engineering consultancy",
    "infrastructure development",
    "transport engineering",
    "energy infrastructure",
    "water management",
    "building design",
    "global engineering",
  ],
  openGraph: {
    title: "Engineering Global | Delivering Excellence",
    description:
      "Global engineering consultancy delivering world-class infrastructure projects across transport, energy, water, and buildings.",
    type: "website",
  },
}

export default async function HomePage() {
  // Fetch data from Strapi CMS
  let projects = []
  let services = []
  let pageContent = null

  try {
    const [projectsData, servicesData, contentData] = await Promise.all([
      getProjects(1, 6),
      getServices(),
      getPageContent(),
    ])
    projects = projectsData.data
    services = servicesData.data
    pageContent = contentData
  } catch (error) {
    console.error("[v0] Error fetching data from Strapi:", error)
    // Use fallback data when Strapi is not connected
  }

  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <main className="flex-1">
        <HeroSection
          title={pageContent?.attributes.heroTitle || "Delivering Excellence"}
          subtitle={
            pageContent?.attributes.heroSubtitle ||
            "We're a global, employee-owned engineering, management and development consultancy"
          }
          imageUrl="/modern-engineering-infrastructure-project.jpg"
        />

        <StatsSection />

        <div className="relative h-[400px] md:h-[500px] w-full">
          <img src="/infrastructure-aerial.jpg" alt="Infrastructure overview" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-transparent to-background/20" />
        </div>

        {/* About Section */}
        <section className="py-20 px-4 md:px-6">
          <div className="container">
            <div className="mx-auto max-w-4xl text-center">
              <h2 className="mb-6 text-4xl font-bold text-foreground md:text-5xl">About Us</h2>
              <p className="text-balance text-lg leading-relaxed text-muted-foreground">
                {pageContent?.attributes.aboutDescription ||
                  "We plan, design, deliver and maintain the transport, energy, water, buildings and wider infrastructure that is integral to people's daily lives. Our technical excellence and innovation transform our clients' businesses, communities and employee opportunities."}
              </p>
              <Button className="mt-8 gap-2" size="lg">
                Learn more about us
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        <div className="relative h-[400px] md:h-[500px] w-full">
          <img src="/engineering-team.jpg" alt="Engineering collaboration" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-transparent to-background/20" />
        </div>

        {/* Projects Section */}
        <section className="bg-muted/30 py-20 px-4 md:px-6">
          <div className="container">
            <div className="mb-12 flex flex-col items-start gap-6 md:flex-row md:items-end md:justify-between">
              <div>
                <h2 className="mb-4 text-4xl font-bold text-foreground md:text-5xl">Delivering great projects</h2>
                <p className="text-lg text-muted-foreground">
                  Applying technical excellence and innovation to deliver projects that transform
                </p>
              </div>
              <Button variant="outline" className="hidden gap-2 md:flex bg-transparent">
                View all projects
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>

            {projects.length > 0 ? (
              <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                {projects.map((project) => (
                  <ProjectCard key={project.id} project={project} />
                ))}
              </div>
            ) : (
              <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                {/* Fallback example projects */}
                {[
                  {
                    title: "Los Angeles Regional Connector",
                    description:
                      "We helped to deliver the Los Angeles Regional Connector, encouraging Angelenos towards public transport.",
                    location: "Los Angeles, USA",
                    region: "North America",
                  },
                  {
                    title: "Kitakyushu Hibikinada Offshore Wind",
                    description:
                      "The largest privately financed offshore wind energy project in Japan provides a model for others to follow.",
                    location: "Kitakyushu, Japan",
                    region: "Asia",
                  },
                  {
                    title: "Ontario Line, Toronto",
                    description:
                      "Toronto's largest and most complex transport project to date, creating sustainable urban mobility.",
                    location: "Toronto, Canada",
                    region: "North America",
                  },
                ].map((project, index) => (
                  <div key={index} className="overflow-hidden rounded-lg bg-card">
                    <div className="relative aspect-[16/10] bg-muted">
                      <img
                        src={`/.jpg?height=400&width=600&query=${project.title}`}
                        alt={project.title}
                        className="h-full w-full object-cover"
                      />
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-primary/80 to-transparent p-4">
                        <span className="text-xs font-medium text-primary-foreground">{project.region}</span>
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="mb-2 text-xl font-semibold text-foreground">{project.title}</h3>
                      <p className="mb-3 text-sm text-muted-foreground">{project.location}</p>
                      <p className="text-sm text-muted-foreground">{project.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-12 text-center md:hidden">
              <Button variant="outline" className="gap-2 bg-transparent">
                View all projects
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        <div className="relative h-[400px] md:h-[500px] w-full">
          <img src="/sustainable-energy.jpg" alt="Sustainable infrastructure" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-transparent to-background/20" />
        </div>

        {/* Services Section */}
        <section className="py-20 px-4 md:px-6">
          <div className="container">
            <div className="mb-12 text-center md:text-left">
              <h2 className="mb-4 text-4xl font-bold text-foreground md:text-5xl">Our expertise</h2>
              <p className="max-w-3xl text-lg text-muted-foreground">
                Whatever your needs, our technical experts are here to help. We mobilise our rich heritage in core
                markets and apply innovation to solve today's challenges.
              </p>
            </div>

            {services.length > 0 ? (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {services.map((service, index) => (
                  <ServiceCard key={service.id} service={service} index={index} />
                ))}
              </div>
            ) : (
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {/* Fallback example services */}
                {[
                  {
                    title: "Buildings",
                    description:
                      "We work across a broad range of building types including commercial, education, healthcare, and residential projects.",
                    icon: "building",
                    slug: "buildings",
                  },
                  {
                    title: "Energy",
                    description:
                      "Unique breadth of energy sector technical expertise to co-create solutions and help you deliver them.",
                    icon: "energy",
                    slug: "energy",
                  },
                  {
                    title: "Transport",
                    description:
                      "Creating solutions that are intuitive and safe to use, maximising wider social, health and environmental outcomes.",
                    icon: "transport",
                    slug: "transport",
                  },
                  {
                    title: "Water",
                    description:
                      "More than a century of water management experience in supply, wastewater, irrigation, and flood protection.",
                    icon: "water",
                    slug: "water",
                  },
                  {
                    title: "Environment & Society",
                    description:
                      "Climate, environment and social experts support sustainability throughout the project lifecycle.",
                    icon: "building",
                    slug: "environment",
                  },
                ].map((service, index) => (
                  <ServiceCard
                    key={index}
                    service={{
                      id: index,
                      attributes: service,
                    }}
                    index={index}
                  />
                ))}
              </div>
            )}
          </div>
        </section>

        <div className="relative h-[400px] md:h-[500px] w-full">
          <img src="/professional-team.jpg" alt="Professional team" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-transparent to-background/20" />
        </div>

        {/* CTA Section */}
        <section className="bg-accent py-20 px-4 md:px-6 text-accent-foreground">
          <div className="container text-center">
            <h2 className="mb-6 text-4xl font-bold md:text-5xl">Build your career with us</h2>
            <p className="mx-auto mb-8 max-w-2xl text-lg opacity-90">
              We are a unique group of experts who work on high-profile projects around the world that address some of
              the world's most pressing issues.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button size="lg" variant="secondary" className="gap-2">
                Search our vacancies
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-accent-foreground text-accent-foreground hover:bg-accent-foreground/10 bg-transparent"
              >
                Meet our people
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
