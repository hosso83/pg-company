// Strapi CMS configuration and utilities
const STRAPI_URL = process.env.NEXT_PUBLIC_STRAPI_URL || "http://localhost:1337"
const STRAPI_API_TOKEN = process.env.STRAPI_API_TOKEN

interface StrapiImage {
  data: {
    id: number
    attributes: {
      url: string
      alternativeText: string
      width: number
      height: number
    }
  }
}

interface StrapiResponse<T> {
  data: T
  meta: {
    pagination?: {
      page: number
      pageSize: number
      pageCount: number
      total: number
    }
  }
}

export interface Project {
  id: number
  attributes: {
    title: string
    description: string
    location: string
    region: string
    image: StrapiImage
    slug: string
    publishedAt: string
  }
}

export interface Service {
  id: number
  attributes: {
    title: string
    description: string
    icon: string
    slug: string
  }
}

export interface TeamMember {
  id: number
  attributes: {
    name: string
    role: string
    location: string
    bio: string
    image: StrapiImage
    slug: string
  }
}

export interface PageContent {
  id: number
  attributes: {
    heroTitle: string
    heroSubtitle: string
    heroImage: StrapiImage
    aboutTitle: string
    aboutDescription: string
  }
}

async function fetchAPI<T>(path: string, options: RequestInit = {}): Promise<StrapiResponse<T> | null> {
  try {
    const headers: HeadersInit = {
      "Content-Type": "application/json",
    }

    if (STRAPI_API_TOKEN) {
      headers["Authorization"] = `Bearer ${STRAPI_API_TOKEN}`
    }

    const response = await fetch(`${STRAPI_URL}/api${path}`, {
      headers,
      cache: "no-store",
      ...options,
    })

    const contentType = response.headers.get("content-type")
    if (!contentType || !contentType.includes("application/json")) {
      console.error(`[v0] Strapi returned non-JSON response for ${path}`)
      return null
    }

    if (!response.ok) {
      throw new Error(`Strapi API error: ${response.status} ${response.statusText}`)
    }

    return response.json()
  } catch (error) {
    return null
  }
}

export async function getProjects(page = 1, pageSize = 8): Promise<StrapiResponse<Project[]>> {
  const response = await fetchAPI<Project[]>(
    `/projects?populate=image&pagination[page]=${page}&pagination[pageSize]=${pageSize}&sort=publishedAt:desc`,
  )
  return response || { data: [], meta: {} }
}

export async function getProjectBySlug(slug: string): Promise<Project | null> {
  try {
    const response = await fetchAPI<Project[]>(`/projects?filters[slug][$eq]=${slug}&populate=image`)
    return response?.data?.[0] || null
  } catch (error) {
    console.error(`[v0] Error fetching project by slug:`, error)
    return null
  }
}

export async function getServiceBySlug(slug: string): Promise<Service | null> {
  try {
    const response = await fetchAPI<Service[]>(`/services?filters[slug][$eq]=${slug}`)
    return response?.data?.[0] || null
  } catch (error) {
    console.error(`[v0] Error fetching service by slug:`, error)
    return null
  }
}

export async function getServices(): Promise<StrapiResponse<Service[]>> {
  const response = await fetchAPI<Service[]>("/services?sort=id:asc")
  return response || { data: [], meta: {} }
}

export async function getTeamMembers(page = 1, pageSize = 8): Promise<StrapiResponse<TeamMember[]>> {
  const response = await fetchAPI<TeamMember[]>(
    `/team-members?populate=image&pagination[page]=${page}&pagination[pageSize]=${pageSize}`,
  )
  return response || { data: [], meta: {} }
}

export async function getTeamMemberBySlug(slug: string): Promise<TeamMember | null> {
  try {
    const response = await fetchAPI<TeamMember[]>(`/team-members?filters[slug][$eq]=${slug}&populate=image`)
    return response?.data?.[0] || null
  } catch (error) {
    console.error(`[v0] Error fetching team member by slug:`, error)
    return null
  }
}

export async function getPageContent(): Promise<PageContent | null> {
  try {
    const response = await fetchAPI<PageContent>("/page-content?populate=heroImage")
    return response?.data || null
  } catch (error) {
    console.error(`[v0] Error fetching page content:`, error)
    return null
  }
}

export function getStrapiMedia(url: string): string {
  if (url.startsWith("http")) {
    return url
  }
  return `${STRAPI_URL}${url}`
}
