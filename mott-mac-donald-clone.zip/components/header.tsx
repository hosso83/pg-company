import Link from "next/link"
import { MobileNav } from "@/components/mobile-nav"

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-32 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center space-x-2 no-hover">
          <div className="flex h-8 w-8 items-center justify-center rounded bg-primary">
            <span className="text-lg font-bold text-primary-foreground">E</span>
          </div>
          <span className="text-xl font-semibold text-foreground uppercase">Engineering Global</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link href="/about" className="nav_link">
            About us
          </Link>
          <Link href="/projects" className="nav_link">
            Projects
          </Link>
          <Link href="/services" className="nav_link">
            Markets & Services
          </Link>
          <Link href="/team" className="nav_link">
            Our People
          </Link>
          <Link href="/careers" className="nav_link">
            Careers
          </Link>
        </nav>

        <MobileNav />
      </div>
    </header>
  )
}
