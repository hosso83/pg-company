"use client"

import Image from "next/image"
import Link from "next/link"
import { Card } from "@/components/ui/card"
import type { Project } from "@/lib/strapi"
import { getStrapiMedia } from "@/lib/strapi"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"

interface ProjectCardProps {
  project: Project
}

export function ProjectCard({ project }: ProjectCardProps) {
  const { ref, isVisible } = useScrollAnimation({ threshold: 0.1 })
  const { title, description, location, region, image, slug } = project.attributes

  return (
    <Link href={`/projects/${slug}`}>
      <Card
        ref={ref as any}
        className={`group overflow-hidden transition-all hover:shadow-lg duration-700 ${
          isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
      >
        <div className="relative aspect-[16/10] overflow-hidden bg-muted">
          {image?.data && (
            <Image
              src={getStrapiMedia(image.data.attributes.url) || "/placeholder.svg"}
              alt={image.data.attributes.alternativeText || title}
              fill
              className="object-cover transition-transform duration-300 group-hover:scale-105"
            />
          )}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-primary/80 to-transparent p-4">
            <span className="text-xs font-medium text-primary-foreground">{region}</span>
          </div>
        </div>
        <div className="p-6">
          <h3 className="mb-2 text-xl font-semibold text-foreground group-hover:text-primary">{title}</h3>
          <p className="mb-3 text-sm text-muted-foreground">{location}</p>
          <p className="line-clamp-2 text-sm text-muted-foreground">{description}</p>
        </div>
      </Card>
    </Link>
  )
}
