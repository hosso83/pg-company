"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import Link from "next/link"
import { useEffect, useState } from "react"

interface HeroSectionProps {
  title: string
  subtitle: string
  imageUrl?: string
}

export function HeroSection({ title, subtitle, imageUrl }: HeroSectionProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <section className="relative h-[600px] w-full overflow-hidden bg-primary/5">
      {imageUrl && (
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: `url(${imageUrl})` }}
        />
      )}
      <div className="container relative flex h-full flex-col items-start justify-center">
        <div className="max-w-3xl space-y-6">
          <h1
            className={`text-balance text-5xl font-bold leading-tight text-foreground md:text-6xl lg:text-7xl transition-all duration-700 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            {title}
          </h1>
          <p
            className={`text-pretty text-xl text-muted-foreground md:text-2xl transition-all duration-700 delay-200 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            {subtitle}
          </p>
          <div
            className={`flex flex-wrap gap-4 transition-all duration-700 delay-400 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <Button size="lg" className="gap-2">
              Explore our work
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Link href="/contact">
              <Button size="lg" variant="outline">
                Contact us
              </Button>
            </Link>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 right-0 h-32 w-32 bg-accent/10" />
    </section>
  )
}
